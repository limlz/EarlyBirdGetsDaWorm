#include "pch.hpp"
#include "pause_menu.hpp"
#include "Settings.hpp"

// --- Textures ---
static AEGfxTexture* pauseTitleTex = nullptr;
static AEGfxTexture* btnResumeTex = nullptr;
static AEGfxTexture* btnOptionsTex = nullptr;
static AEGfxTexture* btnQuitTex = nullptr;
static AEGfxTexture* btnYesTex = nullptr;
static AEGfxTexture* btnNoTex = nullptr;

// --- Variables ---
static bool gamePaused = false;
static bool isUnpausing = false; // Tracks the slide-out animation
static float pauseAlpha = 0.0f;
const float FADE_SPEED = 3.0f;

// --- Quit Confirmation ---
static bool showQuitConfirm = false;
static bool confirmClosing = false;
static bool confirmAccepted = false;
static s8 confirmFontId = -1;
static float yesScale = 1.0f;
static float noScale = 1.0f;
static float confirmFadeAlpha = 0.0f;
static constexpr float CONFIRM_FADE_SPEED = 6.0f;

// --- Menu Animation Variables ---
static float pauseMenuTimer = 0.0f;
static float titleX = -1200.0f;
static float resumeX = -1200.0f;
static float optionsX = -1200.0f;
static float quitX = -1200.0f;

// --- HOVER SCALE VARIABLES ---
static float resumeScale = 1.0f;
static float optionsScale = 1.0f;
static float quitScale = 1.0f;

// --- Procedural Blood Splatter ---
struct BloodDrop {
    float x, y;
    float velX, velY;    // Directional speed
    float friction;      // How quickly it stops sliding
    float targetScaleX, targetScaleY;
    float currentScaleX, currentScaleY;
    float delayTimer;    // Wait this long before spawning (creates bursts)
    float flyTimer;      // Wait this long before hitting the screen and splattering
    bool isActive;
};

const int MAX_BLOOD_DROPS = 5000;
static BloodDrop bloodDrops[MAX_BLOOD_DROPS];

// ==========================================
// Load Textures
// ==========================================
void PauseMenu_Load()
{
    pauseTitleTex = LoadTextureChecked(Assets::Pause_Menu::Title);
    btnResumeTex = LoadTextureChecked(Assets::Pause_Menu::ResumeButton);
    btnOptionsTex = LoadTextureChecked(Assets::Pause_Menu::OptionsButton);
    btnQuitTex = LoadTextureChecked(Assets::Pause_Menu::QuitButton);
    btnYesTex = LoadTextureChecked(Assets::Tutorial::YesButton);
    btnNoTex = LoadTextureChecked(Assets::Tutorial::NoButton);
    confirmFontId = AEGfxCreateFont(Assets::Fonts::Buggy, 30);
	Settings_Load();
}

void PauseMenu_Initialize()
{
    gamePaused = false;
    isUnpausing = false;
    pauseAlpha = 0.0f;
    pauseMenuTimer = 0.0f;
    showQuitConfirm = false;
    confirmClosing = false;
    confirmAccepted = false;
    confirmFadeAlpha = 0.0f;
    yesScale = 1.0f;
    noScale = 1.0f;

    titleX = -1200.0f;
    resumeX = -1200.0f;
    optionsX = -1200.0f;
    quitX = -1200.0f;

    resumeScale = 1.0f;
    optionsScale = 1.0f;
    quitScale = 1.0f;
    Settings_Initialize();
}

void PauseMenu_Update(float dt)
{
    // 1. Check if Settings is open BEFORE we update it.
    bool wasSettingsOpen = Settings_IsOpen();

    // 2. ALWAYS update settings so its fade-out animation can finish, 
    //    and so it can intercept its own Escape key presses.
    Settings_Update(dt);

    // 3. If Settings WAS open at the start of this frame, we MUST return immediately.
    //    This prevents the Pause Menu from seeing the Escape key press that just closed the Settings.
    if (wasSettingsOpen) {
        return;
    }

    float mx = Input_GetMouseX();
    float my = Input_GetMouseY();

    // --- ESCAPE KEY LOGIC ---
    if (AEInputCheckTriggered(AEVK_ESCAPE)) {
        if (!gamePaused) {
            // Start Pause — stop walking SFX immediately so it doesn't loop while frozen
            Player_StopSounds();
            gamePaused = true;
            isUnpausing = false;
            pauseMenuTimer = 0.0f;

            // Reset UI positions back off-screen
            titleX = -1200.0f;
            resumeX = -1200.0f;
            optionsX = -1200.0f;
            quitX = -1200.0f;

            // Reset scales
            resumeScale = 1.0f;
            optionsScale = 1.0f;
            quitScale = 1.0f;

            // --- Generate Directional Splatter ---
            for (int i = 0; i < MAX_BLOOD_DROPS; i++) {
                bloodDrops[i].x = -1000.0f - static_cast<float>(RandInt(0, 399));
                bloodDrops[i].y = static_cast<float>(RandInt(-550, 549));

                bloodDrops[i].velX = static_cast<float>(RandInt(2000, 4999));
                bloodDrops[i].velY = static_cast<float>(RandInt(-700, 699));

                bloodDrops[i].friction = static_cast<float>(RandInt(15, 22));

                float baseScale = static_cast<float>(RandInt(5, 9));

                bloodDrops[i].targetScaleX = baseScale * static_cast<float>(RandInt(1, 4));
                bloodDrops[i].targetScaleY = baseScale * 1.0f;

                bloodDrops[i].currentScaleX = 0.0f;
                bloodDrops[i].currentScaleY = 0.0f;

                int burstGroup = RandInt(0, 3);
                bloodDrops[i].delayTimer = burstGroup * 0.10f;
                bloodDrops[i].flyTimer = static_cast<float>(RandInt(5, 24)) / 100.0f;
                bloodDrops[i].isActive = false;
            }
        }
        else if (!isUnpausing) {
            // Trigger slide out animation
            isUnpausing = true;

            // --- REVERSE BLOOD SPLATTER ---
            for (int i = 0; i < MAX_BLOOD_DROPS; i++) {
                bloodDrops[i].isActive = true;
                bloodDrops[i].flyTimer = 0.0f;
                bloodDrops[i].velX = -static_cast<float>(RandInt(3000, 6999));
                bloodDrops[i].friction = 0.0f;
            }
        }
    }

    // --- ACTIVE PAUSE MENU LOGIC ---
    if (gamePaused) {
        pauseMenuTimer += dt;

        if (!isUnpausing) {
            // --- SLIDE IN ---
            if (pauseMenuTimer > 0.35f) titleX += (-475.0f - titleX) * 15.0f * dt;
            if (pauseMenuTimer > 0.45f) resumeX += (-600.0f - resumeX) * 15.0f * dt;
            if (pauseMenuTimer > 0.55f) optionsX += (-600.0f - optionsX) * 15.0f * dt;
            if (pauseMenuTimer > 0.65f) quitX += (-650.0f - quitX) * 15.0f * dt;

            pauseAlpha += FADE_SPEED * dt;
            if (pauseAlpha > 0.8f) pauseAlpha = 0.8f;
        }
        else {
            // --- SLIDE OUT (UNPAUSING) ---
            titleX += (-1200.0f - titleX) * 15.0f * dt;
            resumeX += (-1200.0f - resumeX) * 15.0f * dt;
            optionsX += (-1200.0f - optionsX) * 15.0f * dt;
            quitX += (-1200.0f - quitX) * 15.0f * dt;

            pauseAlpha -= FADE_SPEED * dt;

            // Once fully faded out, actually unpause the game!
            if (pauseAlpha <= 0.0f) {
                pauseAlpha = 0.0f;
                gamePaused = false;
                isUnpausing = false;
            }
        }

        // --- HOVER LOGIC & SCALING ---
        bool hoverResume = false, hoverOptions = false, hoverQuit = false;

        // Only interact if NOT unpausing and they've started sliding in
        if (!isUnpausing && pauseMenuTimer > 0.45f) {
            hoverResume = IsAreaClicked(resumeX, 100.0f, 300.0f, 60.0f, mx, my);
            hoverOptions = IsAreaClicked(optionsX, 0.0f, 300.0f, 60.0f, mx, my);
            hoverQuit = IsAreaClicked(quitX, -100.0f, 300.0f, 60.0f, mx, my);
        }

        float animSpeed = 15.0f;
        UpdateButtonScale(resumeScale, hoverResume, 1.15f, animSpeed, dt);
        UpdateButtonScale(optionsScale, hoverOptions, 1.15f, animSpeed, dt);
        UpdateButtonScale(quitScale, hoverQuit, 1.15f, animSpeed, dt);


        // --- Directional Splatter Physics ---
        for (int i = 0; i < MAX_BLOOD_DROPS; i++) {

            if (!bloodDrops[i].isActive) {
                bloodDrops[i].delayTimer -= dt;
                if (bloodDrops[i].delayTimer <= 0.0f) {
                    bloodDrops[i].isActive = true;
                }
                continue;
            }

            if (bloodDrops[i].flyTimer > 0.0f) {
                bloodDrops[i].flyTimer -= dt;
                bloodDrops[i].x += bloodDrops[i].velX * dt;
                bloodDrops[i].y += bloodDrops[i].velY * dt;
                bloodDrops[i].currentScaleX = 2.0f;
                bloodDrops[i].currentScaleY = 2.0f;
            }
            else {
                bloodDrops[i].x += bloodDrops[i].velX * dt;
                bloodDrops[i].y += bloodDrops[i].velY * dt;
                bloodDrops[i].velX -= bloodDrops[i].velX * bloodDrops[i].friction * dt;
                bloodDrops[i].velY -= bloodDrops[i].velY * bloodDrops[i].friction * dt;

                float growSpeed = 30.0f;
                bloodDrops[i].currentScaleX += (bloodDrops[i].targetScaleX - bloodDrops[i].currentScaleX) * growSpeed * dt;
                bloodDrops[i].currentScaleY += (bloodDrops[i].targetScaleY - bloodDrops[i].currentScaleY) * growSpeed * dt;
            }
        }

        // --- Check for Button Clicks ---
        if (!isUnpausing && pauseMenuTimer > 0.45f) {
            if (hoverResume && AEInputCheckTriggered(AEVK_LBUTTON)) {
                isUnpausing = true;

                // --- REVERSE BLOOD SPLATTER ---
                for (int i = 0; i < MAX_BLOOD_DROPS; i++) {
                    bloodDrops[i].isActive = true;
                    bloodDrops[i].flyTimer = 0.0f;
                    bloodDrops[i].velX = -static_cast<float>(RandInt(3000, 6999));
                    bloodDrops[i].friction = 0.0f;
                }
            }
            if (hoverOptions && AEInputCheckTriggered(AEVK_LBUTTON)) {
                Settings_Open();
            }
            if (hoverQuit && AEInputCheckTriggered(AEVK_LBUTTON)) {
                showQuitConfirm = true;
                yesScale = 1.0f;
                noScale = 1.0f;
            }
        }

        // --- QUIT CONFIRMATION PROMPT ---
        if (showQuitConfirm) {
            if (confirmClosing) {
                confirmFadeAlpha -= CONFIRM_FADE_SPEED * dt;
                if (confirmFadeAlpha <= 0.0f) {
                    confirmFadeAlpha = 0.0f;
                    showQuitConfirm = false;
                    confirmClosing = false;
                    if (confirmAccepted) {
                        confirmAccepted = false;
                        currentEndReason = EndGameReason::REASON_QUIT_FROM_MENU;
                        Analytics::LogRun(EndGameReason::REASON_QUIT_FROM_MENU, Game_GetCurrentDay(), Player_GetPatientsHandled(), IsGhostPatient(),
                            static_cast<int>(Player_GetTrueDiagnosis()), static_cast<int>(Player_GetAnomalyIllness()), Game_GetTimeSurvived());
                        next = MAIN_MENU;
                    }
                }
            } else {
                confirmFadeAlpha += CONFIRM_FADE_SPEED * dt;
                if (confirmFadeAlpha > 1.0f) confirmFadeAlpha = 1.0f;

                float animSpeed = 15.0f;
                bool hoverYes = IsAreaClicked(-250.0f, -120.0f, 280.0f, 130.0f, mx, my);
                bool hoverNo  = IsAreaClicked( 250.0f, -120.0f, 280.0f, 130.0f, mx, my);

                UpdateButtonScale(yesScale, hoverYes, 1.15f, animSpeed, dt);
                UpdateButtonScale(noScale,  hoverNo,  1.15f, animSpeed, dt);

                if (confirmFadeAlpha >= 0.9f) {
                    if (hoverYes && AEInputCheckTriggered(AEVK_LBUTTON)) {
                        confirmClosing = true;
                        confirmAccepted = true;
                    }
                    if (hoverNo && AEInputCheckTriggered(AEVK_LBUTTON)) {
                        confirmClosing = true;
                        confirmAccepted = false;
                    }
                }
                if (AEInputCheckTriggered(AEVK_ESCAPE)) {
                    confirmClosing = true;
                    confirmAccepted = false;
                }
            }
        }
    }
}

void PauseMenu_Draw(AEGfxVertexList* squareMesh)
{
    if (pauseAlpha <= 0.0f) return;

    // LAYER 1: The Darkening Overlay
    DrawBlackOverlay(squareMesh, pauseAlpha);

    // LAYER 2: PIXELATED Procedural Blood Splatter
    if (gamePaused)
    {
        AEGfxSetColorToMultiply(0.6f, 0.0f, 0.0f, 1.0f);
        AEGfxSetTransparency(pauseAlpha);

        for (int i = 0; i < MAX_BLOOD_DROPS; i++) {
            AEMtx33 scale, trans, finalTransform;

            int pixelScaleX = static_cast<int>(bloodDrops[i].currentScaleX);
            int pixelScaleY = static_cast<int>(bloodDrops[i].currentScaleY);
            int pixelPosX = static_cast<int>(bloodDrops[i].x);
            int pixelPosY = static_cast<int>(bloodDrops[i].y);

            if (pixelScaleX <= 0) pixelScaleX = 1;
            if (pixelScaleY <= 0) pixelScaleY = 1;

            AEMtx33Scale(&scale, static_cast<float>(pixelScaleX), static_cast<float>(pixelScaleY));
            AEMtx33Trans(&trans, static_cast<float>(pixelPosX), static_cast<float>(pixelPosY));
            AEMtx33Concat(&finalTransform, &trans, &scale);
            AEGfxSetTransform(finalTransform.m);

            AEGfxMeshDraw(squareMesh, AE_GFX_MDM_TRIANGLES);
        }
    }

    // ==========================================
    // LAYER 3: The UI Textures (Staggered slide-in & Scaling)
    // ==========================================
    if (gamePaused && pauseMenuTimer > 0.35f)
    {
        // Draw Title (Static scale)
        if (pauseTitleTex) {
            DrawTextureMesh(squareMesh, pauseTitleTex, titleX, 250.0f, 600.0f, 180.0f, 1.0f);
        }

        // Draw Buttons (Multiply width and height by their respective scale variable!)
        if (btnResumeTex) {
            DrawTextureMesh(squareMesh, btnResumeTex, resumeX, 100.0f, 300.0f * resumeScale, 60.0f * resumeScale, 1.0f);
        }
        if (btnOptionsTex) {
            DrawTextureMesh(squareMesh, btnOptionsTex, optionsX, 0.0f, 300.0f * optionsScale, 60.0f * optionsScale, 1.0f);
        }
        if (btnQuitTex) {
            DrawTextureMesh(squareMesh, btnQuitTex, quitX, -100.0f, 200.0f * quitScale, 60.0f * quitScale, 1.0f);
        }
    }

    // LAYER 4: Quit Confirmation Prompt
    if (showQuitConfirm && gamePaused && confirmFadeAlpha > 0.0f) {
        float a = confirmFadeAlpha;

        DrawBlackOverlay(squareMesh, 0.6f * a);

        if (confirmFontId >= 0) {
            AEGfxPrintWithGlow(confirmFontId, "Are you sure?",
                -0.42f, -0.08f, 1.8f,
                1.0f, 1.0f, 1.0f, a,
                0.4f, 0.0f, 0.0f, a * 0.5f,
                0.004f, true);
        }

        if (btnYesTex) {
            DrawTextureMesh(squareMesh, btnYesTex, -250.0f, -120.0f, 280.0f * yesScale, 130.0f * yesScale, a);
        }
        if (btnNoTex) {
            DrawTextureMesh(squareMesh, btnNoTex, 250.0f, -120.0f, 280.0f * noScale, 130.0f * noScale, a);
        }
    }

    // Reset Global Engine State
    AEGfxSetRenderMode(AE_GFX_RM_COLOR);
    AEGfxSetBlendMode(AE_GFX_BM_BLEND);
    AEGfxSetColorToMultiply(1.0f, 1.0f, 1.0f, 1.0f);
    AEGfxSetColorToAdd(0.0f, 0.0f, 0.0f, 0.0f);
    AEGfxSetTransparency(1.0f);

    // --- NEW: Draw Settings ON TOP of the pause menu ---
    // Just pass the mesh since Settings handles its own textures/fonts now!
    Settings_Draw(squareMesh);
}

// ==========================================
// Unload Textures
// ==========================================
void PauseMenu_Unload()
{
    UnloadTextureSafe(pauseTitleTex);
    UnloadTextureSafe(btnResumeTex);
    UnloadTextureSafe(btnOptionsTex);
    UnloadTextureSafe(btnQuitTex);
    UnloadTextureSafe(btnYesTex);
    UnloadTextureSafe(btnNoTex);
    if (confirmFontId >= 0) { AEGfxDestroyFont(confirmFontId); confirmFontId = -1; }
	Settings_Unload();
}

bool PauseMenu_IsPaused()
{
    return gamePaused;
}

void PauseMenu_SetPaused(bool state)
{
    gamePaused = state;
}
// ============================================================
// JUMPSCARE MODULE
// Handles the full-screen jumpscare effect:
//
// - Triggers jumpscare (press J to test)
// - Updates screen shake + image shake + optional flash
// - Draws motion-blur trails + jumpscare texture (top layer)
// - Provides shake offset (optional camera offset use)
// ============================================================

#include "pch.hpp"
#include <algorithm> // std::max

// ============================================================
// CONFIG
// ============================================================

// Jumpscare timing values are driven by Config (Assets/config.txt)
// Keys: JUMPSCARE_DURATION, JUMPSCARE_SCREEN_SHAKE, JUMPSCARE_IMAGE_SHAKE, JUMPSCARE_FLASH_DURATION

// ============================================================
// RENDER DATA (Texture + Mesh)
// ============================================================

static AEGfxVertexList* gQuadMesh = nullptr;    // quad mesh for drawing texture fullscreen
static AEGfxTexture* gJumpScareTex = nullptr;   // jumpscare image

// ============================================================
// STATE
// ============================================================

static bool  gActive = false;
static float gTimer = 0.0f;

static float gShakeX = 0.0f;   // screen/camera shake offset
static float gShakeY = 0.0f;
static float gFlashTimer = 0.0f;   

// ============================================================
// HELPERS
// ============================================================

static float Clamp01(float x)
{
    if (x < 0.0f) return 0.0f;
    if (x > 1.0f) return 1.0f;
    return x;
}

static float RandMinus1To1()
{
    // [-1, 1]
    return RandFloat(-1.0f, 1.0f);
}

// ============================================================
// LOAD / INIT / UNLOAD
// Call from Game_Load / Game_Initialize / Game_Unload
// ============================================================

void JumpScare_Load()
{
    gJumpScareTex = LoadTextureChecked(Assets::Background::JumpScare);
    gQuadMesh = CreateSquareMesh(0xFFFFFFFF);
}

void JumpScare_Initialize()
{
    // Reset runtime state
    gActive = false;
    gTimer = 0.0f;
    gShakeX = 0.0f;
    gShakeY = 0.0f;
    gFlashTimer = 0.0f;
}

void JumpScare_Unload()
{
    UnloadTextureSafe(gJumpScareTex);
    FreeMeshSafe(gQuadMesh);

    gActive = false;
    gTimer = 0.0f;
    gShakeX = 0.0f;
    gShakeY = 0.0f;
    gFlashTimer = 0.0f;
}

// ============================================================
// TRIGGER
// ============================================================

void JumpScare_Start()
{
    gActive = true;
    gTimer = Config::jumpscareDuration;

    gShakeX = 0.0f;
    gShakeY = 0.0f;

    gFlashTimer = Config::jumpscareFlashDuration; // optional quick flash at start

    if (Settings_IsHorrorLessEnabled()) {
        AudioManager_PlaySFX(SoundID::SFX_AA, 1.0f, 1.5f, 0); // AA
    }
    else {
        AudioManager_PlaySFX(SoundID::SFX_SCREAMING, 0.65f);
    }
}

// ============================================================
// UPDATE
// Call inside Game_Update(dt)
// Return true if you want to freeze gameplay while active
// ============================================================

bool JumpScare_Update(float dt)
{
    // Press J to test (debug only)
    if (!gActive && Debug_IsActive() && AEInputCheckTriggered(AEVK_J))
        JumpScare_Start();

    if (!gActive)
        return false;

    // --------------------------------------------
    // 1) Countdown + End condition
    // --------------------------------------------
    gTimer -= dt;
    if (gTimer <= 0.0f)
    {
        gActive = false;
        gTimer = 0.0f;
        gShakeX = 0.0f;
        gShakeY = 0.0f;
        gFlashTimer = 0.0f;

        AudioManager_StopSFX();
        return false; // finished, resume gameplay
    }

    // --------------------------------------------
    // 2) Flash timer
    // --------------------------------------------
    if (gFlashTimer > 0.0f)
    {
        gFlashTimer -= dt;
        if (gFlashTimer < 0.0f) gFlashTimer = 0.0f;
    }

    // --------------------------------------------
    // 3) Screen shake with decay
    //    Strong at start, weaker near the end
    // --------------------------------------------
    float t = Clamp01(gTimer / Config::jumpscareDuration); // 1 -> 0
    float s = Config::jumpscareScreenShake * t;

    gShakeX = RandMinus1To1() * s;
    gShakeY = RandMinus1To1() * s;

    // If you want to fully freeze gameplay while the jumpscare runs:
    return true;
}

// ============================================================
// SHAKE OFFSET (Optional camera offset hook)
// Use if you want to apply screen shake to world/UI transforms
// ============================================================

void JumpScare_GetShakeOffset(float& outX, float& outY)
{
    outX = (gActive ? gShakeX : 0.0f);
    outY = (gActive ? gShakeY : 0.0f);
}

// ============================================================
// DRAW
// Call at the VERY END of Game_Draw() (top layer)
// ============================================================

void JumpScare_Draw()
{
    if (!gActive) return;

    DrawBlackOverlay(gQuadMesh, 0.8f);

    AEGfxSetBlendMode(AE_GFX_BM_BLEND);

    const float W = SCREEN_WIDTH_HALF * 2.0f;
    const float H = SCREEN_HEIGHT_HALF * 2.0f;

    // Extra shake for the image itself (separate from screen shake)
    float imgX = RandMinus1To1() * Config::jumpscareImageShake;
    float imgY = RandMinus1To1() * Config::jumpscareImageShake;

    const float baseX = gShakeX + imgX;
    const float baseY = gShakeY + imgY;

    // If texture failed, show a clear fallback
    if (!gJumpScareTex || !gQuadMesh)
    {
        DrawSquareMesh(gQuadMesh, 0.0f, 0.0f, W, H, 0xFFFFFFFF);
        return;
    }

    // --------------------------------------------
    // 1) Fake motion blur trails
    // --------------------------------------------
    DrawTextureMesh(gQuadMesh, gJumpScareTex, baseX - 10.0f, baseY, W, H, 0.20f);
    DrawTextureMesh(gQuadMesh, gJumpScareTex, baseX + 10.0f, baseY, W, H, 0.20f);
    DrawTextureMesh(gQuadMesh, gJumpScareTex, baseX, baseY - 8.0f, W, H, 0.20f);

    // --------------------------------------------
    // 2) Main image
    // --------------------------------------------
    DrawTextureMesh(gQuadMesh, gJumpScareTex, baseX, baseY, W, H, 1.0f);
}

// ============================================================
// PUBLIC GETTERS
// ============================================================

bool JumpScare_IsActive()
{
    return gActive;
}

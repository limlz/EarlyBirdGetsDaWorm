#include "pch.hpp"

AEGfxTexture* LoadTextureChecked(const char* path)
{
	AEGfxTexture* texture = AEGfxTextureLoad(path);
	if (!texture)
	{
		std::cerr << "FATAL: FAILED TO LOAD TEXTURE: " << path << "\n";
		AE_ASSERT_MESG(texture, "LoadTextureChecked: texture file not found or failed to load!");
	}
	return texture;
}

void UnloadTextureSafe(AEGfxTexture*& texture)
{
	if (texture)
	{
		AEGfxTextureUnload(texture);
		texture = nullptr;
	}
}

void FreeMeshSafe(AEGfxVertexList*& mesh)
{
	if (mesh)
	{
		AEGfxMeshFree(mesh);
		mesh = nullptr;
	}
}

bool CircleCollision(f32 x1, f32 y1, f32 r1, f32 x2, f32 y2, f32 r2)
{
	f32 dx = x2 - x1;
	f32 dy = y2 - y1;
	f32 distanceSquared = dx * dx + dy * dy;
	f32 radiusSum = r1 + r2;
	return distanceSquared <= (radiusSum * radiusSum);
}

bool IsAreaClicked(float area_center_x, float area_center_y, float area_width, float area_height, float click_x, float click_y)
{
	float area_width_half = area_width / 2;
	float area_height_half = area_height / 2;
	if (click_x < area_center_x + area_width_half &&
		click_x > area_center_x - area_width_half &&
		click_y < area_center_y + area_height_half &&
		click_y > area_center_y - area_height_half) {
		return true;
	}
	else {
		return false;
	}
}

bool IsAreaClickedByMouse(float area_center_x, float area_center_y, float area_width, float area_height)
{
	return IsAreaClicked(area_center_x, area_center_y, area_width, area_height, Input_GetMouseX(), Input_GetMouseY());
}

void AEGfxPrintCentered(s8 fontId, const std::string& text, float centerX, float y, float scale, float r, float g, float b, float a, float offset)
{
	// ESTIMATION: Assume average character width is roughly 0.03 NDC units at scale 1.0
	float estimatedCharWidth = offset * scale;

	// Calculate total width using .length()
	float totalWidth = text.length() * estimatedCharWidth;

	// Apply centering formula: Center - (Width / 2)
	float startX = centerX - (totalWidth / 2.0f);

	// Use .c_str() to convert the C++ string back to the C-style pointer the engine needs
	AEGfxPrint(fontId, text.c_str(), startX, y, scale, r, g, b, a);
}

void AEGfxPrintWithGlow(s8 fontId, const char* text, float x, float y, float scale,
	float textR, float textG, float textB, float textA,
	float glowR, float glowG, float glowB, float glowA,
	float glowOffset, bool includeDiagonals)
{
	AEGfxPrint(fontId, text, x - glowOffset, y, scale, glowR, glowG, glowB, glowA);
	AEGfxPrint(fontId, text, x + glowOffset, y, scale, glowR, glowG, glowB, glowA);
	AEGfxPrint(fontId, text, x, y - glowOffset, scale, glowR, glowG, glowB, glowA);
	AEGfxPrint(fontId, text, x, y + glowOffset, scale, glowR, glowG, glowB, glowA);

	if (includeDiagonals)
	{
		AEGfxPrint(fontId, text, x - glowOffset, y - glowOffset, scale, glowR, glowG, glowB, glowA);
		AEGfxPrint(fontId, text, x + glowOffset, y - glowOffset, scale, glowR, glowG, glowB, glowA);
		AEGfxPrint(fontId, text, x - glowOffset, y + glowOffset, scale, glowR, glowG, glowB, glowA);
		AEGfxPrint(fontId, text, x + glowOffset, y + glowOffset, scale, glowR, glowG, glowB, glowA);
	}

	AEGfxPrint(fontId, text, x, y, scale, textR, textG, textB, textA);
}

bool IsColliding(float r1x, float r1y, float r1w, float r1h,
	float r2x, float r2y, float r2w, float r2h)
{
	// AABB (Axis-Aligned Bounding Box) Collision
	// If ANY of these is true, they are NOT overlapping
	if (r1x - r1w / 2 > r2x + r2w / 2) return false; // R1 is right of R2
	if (r1x + r1w / 2 < r2x - r2w / 2) return false; // R1 is left of R2
	if (r1y - r1h / 2 > r2y + r2h / 2) return false; // R1 is above R2
	if (r1y + r1h / 2 < r2y - r2h / 2) return false; // R1 is below R2

	return true; // None were true, so they must be touching
}

void DrawBlackOverlay(AEGfxVertexList* mesh, float alpha)
{
	if (alpha <= 0.0f) return;
	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	AEGfxSetRenderMode(AE_GFX_RM_COLOR);
	AEGfxSetTransparency(alpha);
	AEGfxSetColorToMultiply(0.0f, 0.0f, 0.0f, 1.0f);
	AEMtx33 scale, trans, transform;
	AEMtx33Scale(&scale, 1600.0f, 900.0f);
	AEMtx33Trans(&trans, 0.0f, 0.0f);
	AEMtx33Concat(&transform, &trans, &scale);
	AEGfxSetTransform(transform.m);
	AEGfxMeshDraw(mesh, AE_GFX_MDM_TRIANGLES);
}

void UpdateButtonScale(float& scale, bool hovering, float hoverTarget, float animSpeed, float dt)
{
	scale += ((hovering ? hoverTarget : 1.0f) - scale) * animSpeed * dt;
}

// Converts pager-local pixel offset to normalized screen coordinates for AEGfxPrint
// Basically put both ur XY values in the parameters.
// To get X value: textPosition(X, Y).first
// To get Y value: textPosition(X, Y).second
std::pair<f32, f32> textPosition(float adjustX, float adjustY)
{
	f32 textX = adjustX / (AEGfxGetWindowWidth() * 0.5f);
	f32 textY = adjustY / (AEGfxGetWindowHeight() * 0.5f);
	return { textX, textY };
}

// Returns true if area is being hovered
bool IsAreaHovered(f32 areaX, f32 areaY, f32 areaW, f32 areaH) {
	return IsAreaClicked(areaX, areaY, areaW, areaH, Input_GetMouseX(), Input_GetMouseY());
}

// Animates the hover 
void HoverAnimation(f32& alpha, bool hovered, f32 speed, f32 dt, f32 minAlpha, f32 maxAlpha) {
	f32 targetAlpha = hovered ? maxAlpha : minAlpha;

	// Proper interpolation
	alpha += (targetAlpha - alpha) * speed * dt;

	// Clamp safely (handle swapped values too)
	f32 minVal = min(minAlpha, maxAlpha);
	f32 maxVal = max(minAlpha, maxAlpha);

	alpha = AEClamp(alpha, minVal, maxVal);
}

// --- RNG UTILITIES ---
// sGlobalRng lives inside GetGlobalRng() as a function-local static.
// This guarantees it is initialized on first call (C++11 magic statics),
// avoiding the static initialization order fiasco when other file-scope
// statics (e.g. Analytics::gSessionId) call RandInt() before WinMain.
std::mt19937& GetGlobalRng() {
	static std::mt19937 sGlobalRng(static_cast<unsigned>(std::time(nullptr)));
	return sGlobalRng;
}

int RandInt(int min, int max) {
	std::uniform_int_distribution<int> dist(min, max);
	return dist(GetGlobalRng());
}

float RandFloat(float min, float max) {
	std::uniform_real_distribution<float> dist(min, max);
	return dist(GetGlobalRng());
}
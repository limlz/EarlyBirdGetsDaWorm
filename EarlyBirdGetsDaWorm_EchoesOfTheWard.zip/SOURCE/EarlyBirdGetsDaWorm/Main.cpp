// ---------------------------------------------------------------------------
// Main.cpp
// ---------------------------------------------------------------------------
#include "pch.hpp"
#include "Credits.hpp"
#include <crtdbg.h>

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPWSTR lpCmdLine, _In_ int nCmdShow)
{
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF);
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    int gGameRunning = 1;

    // Initialize System
    AESysInit(hInstance, nCmdShow, 1600, 900, 1, 60, true, nullptr);
    AESysSetWindowTitle("Echoes of the Ward");
    AESysReset();

    // Initialize Game State Manager (Start at Menu or Game)
    GSM_Initialize(START_UP);
    AESysSetFullScreen(0);

    // --- SAFE MAIN LOOP ---
    while (gGameRunning)
    {
        // 0. System Check
        if (0 == AESysDoesWindowExist())
            gGameRunning = 0;

        // 1. Update Function Pointers
        // We do this at the start to ensure fpLoad/fpInit match 'current'
        GSM_Update();

        // 2. Load Resources / Initialize Variables
        if (GSM_ShouldRunLoadAndInitialize()) {
            fpLoad();
            fpInitialize();
        }

        // 4. Inner Game Loop (Runs every frame)
        while (current == next)
        {
            AESysFrameStart();

            // Handle Input
            Input_Update();

            // Game Logic
            fpUpdate();

            // Rendering
            fpDraw();

            AESysFrameEnd();
        }

        // 5. Free Session Data (Variables, Vectors, etc.)
        if (!GSM_ShouldPreserveCurrentStateOnExit()) {
            fpFree();
        }

        // 6. Handle State Transitions
        if (next == GS_QUIT) {
            // Unload the current state before quitting
            fpUnload();
            gGameRunning = 0;
            break; // BREAK IMMEDIATELY to stop the loop
        }
        else if (next == GS_RESTART) {
            fpUnload();

            next = current;
        }
        else {
            if (!GSM_ShouldPreserveCurrentStateOnExit()) {
                fpUnload(); // Unload current state assets
            }

            // If the game state was suspended (preserved) for the boss fight, but we're NOT
            // returning to the game (e.g. player died → ENDGAME), the preserved game resources
            // were never freed. Clean them up now before moving on.
            if (current == BOSS_FIGHT_STATE && next != GAME_STATE && GSM_WasGameSuspendedForBoss()) {
                Game_Unload();
            }

            previous = current;
            current = next;
            GSM_OnStateTransition();
        }
    }

    AudioManager_Unload();
    Analytics::Shutdown();    // free session-ID string before _CrtDumpMemoryLeaks runs
    CentralPool_Shutdown();   // free static vector buffers before _CrtDumpMemoryLeaks runs
    Journal_Shutdown();       // free Observed/Unread vector buffers before _CrtDumpMemoryLeaks runs
    Credits_Shutdown();       // free parsedCredits vector buffer before _CrtDumpMemoryLeaks runs
    AESysExit();
    _CrtDumpMemoryLeaks();
    return 0;
}